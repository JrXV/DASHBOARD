import { Calendar, RefreshCw, LayoutDashboard, Database, FileText, BarChart3, Settings, User } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Dashboard() {
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            <h1 className="text-xl font-semibold">ShrimpSort</h1>
          </div>
        </div>
        <nav className="p-2">
          <div className="space-y-1">
            <SidebarItem icon={<LayoutDashboard size={18} />} label="Dashboard" active />
            <SidebarItem icon={<Database size={18} />} label="Bins Management" />
            <SidebarItem icon={<FileText size={18} />} label="Data Entry" />
            <SidebarItem icon={<BarChart3 size={18} />} label="Reports" />
            <div className="border-t my-4 border-gray-200" />
            <SidebarItem icon={<Settings size={18} />} label="Settings" />
          </div>
          <div className="absolute bottom-4 left-4 right-4">
            <SidebarItem icon={<User size={18} />} label="Operator" />
          </div>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-2">
              <LayoutDashboard className="h-5 w-5 text-gray-500" />
              <h2 className="text-lg font-medium text-gray-700">Dashboard</h2>
            </div>
            <button className="p-2 rounded-full hover:bg-gray-100">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-gray-500"
              >
                <circle cx="12" cy="12" r="1" />
                <circle cx="12" cy="5" r="1" />
                <circle cx="12" cy="19" r="1" />
              </svg>
            </button>
          </div>

          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-800">Shrimp Sorting Dashboard</h1>
            <p className="text-gray-500">Monitor and manage your shrimp sorting operations</p>
          </div>

          <div className="flex justify-between items-center mb-6">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="bins">Bins</TabsTrigger>
                <TabsTrigger value="data">Data</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-md px-3 py-1.5">
              <Calendar className="h-4 w-4 text-gray-500" />
              <span className="text-sm">Apr 07, 2025 - Apr 07, 2025</span>
              <RefreshCw className="h-4 w-4 text-gray-500 ml-2" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MetricCard
              title="Total Processed"
              value="1,245 kg"
              change="+20.1% from last month"
              icon="$"
              iconColor="bg-gray-100 text-gray-700"
            />
            <MetricCard
              title="Small Size"
              value="432 kg"
              change="34.7% of total"
              icon="•"
              iconColor="bg-blue-100 text-blue-500"
            />
            <MetricCard
              title="Medium Size"
              value="587 kg"
              change="47.1% of total"
              icon="•"
              iconColor="bg-green-100 text-green-500"
            />
            <MetricCard
              title="Large Size"
              value="226 kg"
              change="18.2% of total"
              icon="•"
              iconColor="bg-purple-100 text-purple-500"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="col-span-2">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-1">Sorting Trends</h3>
                <p className="text-sm text-gray-500 mb-4">Daily sorting volumes by size category</p>
                <div className="h-64 flex items-center justify-center text-gray-400">Chart would appear here</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-1">Size Distribution</h3>
                <p className="text-sm text-gray-500 mb-4">Percentage breakdown by size</p>
                <div className="h-64 flex items-center justify-center text-gray-400">Chart would appear here</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

function SidebarItem({ icon, label, active = false }) {
  return (
    <div
      className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm ${active ? "bg-gray-100 font-medium" : "text-gray-700 hover:bg-gray-50"}`}
    >
      <span className="text-gray-500">{icon}</span>
      <span>{label}</span>
    </div>
  )
}

function MetricCard({ title, value, change, icon, iconColor }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-sm font-medium text-gray-700">{title}</h3>
          <div className={`w-6 h-6 rounded-full flex items-center justify-center ${iconColor}`}>{icon}</div>
        </div>
        <div className="space-y-1">
          <p className="text-3xl font-bold">{value}</p>
          <p className="text-sm text-gray-500">{change}</p>
        </div>
      </CardContent>
    </Card>
  )
}

